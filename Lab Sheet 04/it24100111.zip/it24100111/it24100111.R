setwd("C:\\Users\\it24100111\\Desktop\\it24100111")

##Importing the data set
data <- read.table("DATA 4.txt",header=TRUE, sep = "")

##view the file in a separate window
fix(data)

##Attach the file into R. So, you can call the variables by their names.
attach (data)



##Part 2
##Part (a)
##Obtaining Box Plots
boxplot (X1,main="Box plot for Team Attendence", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X2,main="Box plot for Team Salary", outline=TRUE, outpch=8,horizontal=TRUE)
boxplot (X3,main="Box plot for Years", outline=TRUE, outpch=8,horizontal=TRUE)

##obtaining Histogram
hist(X1,ylab="Frequency",xlab="Team Attendence",main="Histogram for Team Attendence")
hist(X2,ylab="Frequency",xlab="Team Salary",main="Histogram for Team Salary")
hist(X3,ylab="Frequency",xlab="Years", main="Histogram for Years")

#Stem & Leaf Plot
stem(X1)
stem(X2)
stem(X3)

##Part (b)
##Mean
mean (X1)
mean (X2)
mean (X3)

##Median
median (X1)
median (X2)
median(X3)

##Standard Deviation
sd(X1)
sd(X2)
sd(X3)

##Part (c)
##Getting five number summary along with mean value
summary(X1)
summary(X2)
summary(X3)

##Getting only five number summary for X1 variable
quantile(X1)

##Calling first Quartile of X1 using index value
quantile(X1) [2]

##Calling third Quartile of X1 using index value
quantile(X1) [4]

##Part (d)
##Obtaining Inter Quartile Range (IQR) of each variable
IQR (X1)
IQR(X2)
IQR(X3)


##Part 3
##Function to get the mode of a data set
get.mode <- function(y){
  counts <- table(X3)
  names (counts [counts == max(counts)])
}
  
  ##Obtaining the mode of a variable using the function defined above
  get.mode (X3)
  
  ###Explanation on how each command inside the function works
  ##Following command is to get the frequency table for the variable
  table(X3)
  
  ##Following command will give the maximum frequency in the frequency table
  max(counts)
  
  ##Following command will check whether frequencies in the frequency table equals
  ##to the maximum frequency obtained
  counts == max(counts)
  
  ##This extracts both value and the frequency which gives "TRUE" in earlier logical function
  counts [counts == max(counts)]
  ##This extracts the value which gives maximum frequency (mode) in earlier logical function
  names (counts [counts == max(counts)])

  
  ##Part 4
  ##Function to check the existence of outliers of a data set
  get.outliers <- function(z){
    q1 <- quantile(z) [2]
    q3 <- quantile(z) [4]
    iqr <- q3 - q1
    
    ub <- q3 + 1.5*iqr
    lb <- q1 - 1.5*iqr
    
    print(paste("Upper Bound = ", ub))
    print(paste("Lower Bound = ", lb))
    print(paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse = ",")))
  }
  
    ##Checking the outliers of a variable using the function defined above
    get.outliers (X1)
    get.outliers (X2)
    get.outliers (X3)
    
    
    ###Explanation on how each command inside the function works
    ##Following command is to calculate the interval for outliers
    get.outliers <- function(z){
      q1 <- quantile(z)[2]
      q3 <- quantile(z)[4]
      iqr <- q3 - q1
      
      ub <- q3 + 1.5*iqr
      lb <- q1 - 1.5*iqr
      
    
  
    
    ##Following command is to display the upper boundry and lower boundry of the interval
    print(paste("Upper Bound = ", ub))
    print(paste("Lower Bound = ", lb))
    
    ##Checking the existence of outliers and Display the outliers if exists
    print(paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse = ",")))
    }
    
    
    
#Exercise  
    
    #1
    branch_data <- read.table("DATA 4.txt", header = TRUE, sep = "")    
    
    #2
    str(branch_data)
    
    
  #3
    boxplot(branch_data$X1, main = "Box plot for Team Attendance", outline = TRUE, outpch = 8, horizontal = TRUE)
    
    
  #4
    # Five number summary
    summary(branch_data$X2)
    
    # IQR
    IQR(branch_data$X2)
    
  #5
    get.outliers <- function(z) {
      q1 <- quantile(z)[2]
      q3 <- quantile(z)[4]
      iqr <- q3 - q1
      ub <- q3 + 1.5 * iqr
      lb <- q1 - 1.5 * iqr
      print(paste("Upper Bound = ", ub))
      print(paste("Lower Bound = ", lb))
      print(paste("Outliers:", paste(sort(z[z < lb | z > ub]), collapse = ",")))
    }
    
    # Check outliers for X3 (Years)
    get.outliers(branch_data$X3)